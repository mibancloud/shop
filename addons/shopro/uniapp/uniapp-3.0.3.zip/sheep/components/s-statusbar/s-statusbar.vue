<template>
  <view class="status_bar"></view>
</template>

<style>
  .status_bar {
    height: var(--status-bar-height);
    width: 100%;
  }
</style>
