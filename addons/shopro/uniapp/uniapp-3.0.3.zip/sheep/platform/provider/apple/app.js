import third from '@/sheep/api/third';

const login = () => {
  return new Promise(async (resolve, reject) => {
    const loginRes = await uni.login({
      provider: 'apple',
      success: () => {
        uni.getUserInfo({
          provider: 'apple',
          success: async (res) => {
            if (res.errMsg === 'getUserInfo:ok') {
              const payload = res.userInfo;
              const { code } = await third.apple.login({
                payload,
                shareInfo: uni.getStorageSync('shareLog') || {},
              });
              if (code === 1) {
                resolve(true);
              } else {
                resolve(false);
              }
            }
          },
        });
      },
      fail: (err) => {
        resolve(false);
      },
    });
  });
};

export default {
  login,
};
