export default {
  props: {},
};
